from ursina import *
from ursina.prefabs.first_person_controller import FirstPersonController
from ursina.prefabs.sky import Sky
from create import createMaze

app = Ursina()

wall_texture = load_texture("texture/brick.png")
start_texture = load_texture("texture/redstoneblock.jpg")
end_texture = load_texture("texture/greendiamondblock.jpg")
ground_texture = load_texture("texture/plank.jpg")


class Wall(Button):
    def __init__(self, position):
        super().__init__(
            parent=scene,
            model="cube",
            texture=wall_texture,
            color=color.white,
            position=position,
            origin_y=0.5
        )


class Start(Button):
    def __init__(self, position):
        super().__init__(
            parent=scene,
            model="cube",
            texture=start_texture,
            color=color.white,
            position=position,
            origin_y=0.5
        )


class End(Button):
    def __init__(self, position):
        super().__init__(
            parent=scene,
            model="cube",
            texture=end_texture,
            color=color.white,
            position=position,
            origin_y=0.5
        )


class Ground(Button):
    def __init__(self, position):
        super().__init__(
            parent=scene,
            model="cube",
            texture=ground_texture,
            color=color.white,
            position=position,
            origin_y=0.5
        )


class Player(FirstPersonController):
    def __init__(self):
        global startPosition
        super().__init__()
        camera.fov = 140
        self.position = startPosition
        self.gravity = 0.01
        self.speed = 6
        self.mouse_sensitivity = Vec2(160, 160)

    def jump(self):
        pass


maze = createMaze(15, 15)
startPosition = None
endPosition = None
banPostions = []
for y in range(1, 4):
    for x, row in enumerate(maze):
        for z, value in enumerate(row):
            if str(value) == "s":
                Start((x * 2, 0, z * 2))
                Start((x * 2, 0, z * 2 + 1))
                Start((x * 2 + 1, 0, z * 2))
                Start((x * 2 + 1, 0, z * 2 + 1))
                startPosition = (x * 2, 3, z * 2)
                banPostions.append([x * 2, z * 2])
                banPostions.append([x * 2, z * 2 + 1])
                banPostions.append([x * 2 + 1, z * 2])
                banPostions.append([x * 2 + 1, z * 2 + 1])
            elif str(value) == "e":
                End((x * 2, 0, z * 2))
                End((x * 2, 0, z * 2 + 1))
                End((x * 2 + 1, 0, z * 2))
                End((x * 2 + 1, 0, z * 2 + 1))
                endPosition = (x * 2, 3, z * 2)
                banPostions.append([x * 2, z * 2])
                banPostions.append([x * 2, z * 2 + 1])
                banPostions.append([x * 2 + 1, z * 2])
                banPostions.append([x * 2 + 1, z * 2 + 1])
            elif str(value) == "0":
                Wall((x * 2, y, z * 2))
                Wall((x * 2, y, z * 2 + 1))
                Wall((x * 2 + 1, y, z * 2))
                Wall((x * 2 + 1, y, z * 2 + 1))

y2 = 0
for x2 in range(x * 2 + 1):
    for z2 in range(z * 2 + 1):
        if not ([x2, z2] in banPostions):
            Ground((x2, y2, z2))

player = Player()
sky = Sky()

app.run()