import random as rd

nearmaybe = [
    [-2, 0],
    [2, 0],
    [0, -2],
    [0, 2]
]


def createMaze(row, col):
    maze = [[0 for i in range(col)] for i in range(row)]
    check = []
    firstrow = rd.randrange(1, row - 2, 2)
    firstcol = rd.randrange(1, col - 2, 2)
    maze[firstrow][firstcol] = 1
    check.append([firstrow, firstcol])
    while len(check):
        c = rd.choice(check)
        nears = []
        conditions = []
        for maybe in nearmaybe:
            conditions.append([c[0] + maybe[0], c[1] + maybe[1]])
        for condition in conditions:
            if condition[0] >= 1 and condition[0] <= row - 2 \
                    and condition[1] >= 1 and condition[1] <= col - 2:
                nears.append([condition[0], condition[1]])
        for n in nears.copy():
            if maze[n[0]][n[1]]:
                nears.remove(n)
        for block in nears:
            if block[0] == c[0]:
                if block[1] < c[1]:
                    maze[block[0]][c[1] - 1] = 1
                    maze[block[0]][block[1]] = 1
                    check.append([block[0], block[1]])
                else:
                    maze[block[0]][block[1] - 1] = 1
                    maze[block[0]][block[1]] = 1
                    check.append([block[0], block[1]])
            else:
                if block[0] < c[0]:
                    maze[c[0] - 1][block[1]] = 1
                    maze[block[0]][block[1]] = 1
                    check.append([block[0], block[1]])
                else:
                    maze[block[0] - 1][block[1]] = 1
                    maze[block[0]][block[1]] = 1
                    check.append([block[0], block[1]])
        if not len(nears):
            check.remove(c)
    maze[1][1] = "s"
    while True:
        c = rd.randint(1, col - 2)
        if maze[row - 2][c]:
            maze[row - 2][c] = "e"
            break

    return maze